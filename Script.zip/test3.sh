#!/bin/sh
X=`cat /etc/login.defs | grep PASS_MAX_DAYS | sed -n '2p'`
echo "${X}"
