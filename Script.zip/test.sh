#!/bin/bash
X=12
echo "${X}"
