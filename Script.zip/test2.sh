#!/bin/bash

echo "root password"
echo "-------------"
X=`cat /etc/passwd | grep root | sed -n '1p' | awk -F: '{print $2}'`


if [ $X = x ]
	then echo "OK"
else
	echo "NOT OKAY"
fi

echo $X
