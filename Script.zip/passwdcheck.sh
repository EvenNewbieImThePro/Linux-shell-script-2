#!/bin/bash

X=`ls -l /etc/passwd | grep rw-r--r-- | awk '{print $1}'`
echo ${X}

if [ $X="-rw-r--r--" ]
	then echo "OK"
else 	
	echo "NOT OKAY"
fi




